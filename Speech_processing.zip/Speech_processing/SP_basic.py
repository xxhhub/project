#2023.12.21
#语音处理基础
#https://blog.csdn.net/chinabing/article/details/129052621?spm=1001.2101.3001.6661.1&utm_medium=distribute.pc_relevant_t0.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-1-129052621-blog-128503618.235%5Ev39%5Epc_relevant_anti_t3_base&depth_1-utm_source=distribute.pc_relevant_t0.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-1-129052621-blog-128503618.235%5Ev39%5Epc_relevant_anti_t3_base&utm_relevant_index=1

import wave
import matplotlib.pyplot as plt
import numpy as np
import os
import struct

filepath = "./data/pineapple/"  # 添加路径
filelist = os.listdir(filepath)  # 得到文件夹下的所有文件名称
f = wave.open(filepath + filelist[1], 'rb') #rb读取文件，wb写入文件
params = f.getparams()
nchannels, sampwidth, framerate, nframes = params[:4]
#nchannels声道数、sampwidth量化位数byte、framerate采样频率、nframes采样点数
strData = f.readframes(nframes)  # 读取音频，字符串格式
waveData = np.fromstring(strData, dtype=np.int16)  # 将字符串转化为int
waveData = waveData * 1.0 / (max(abs(waveData)))  # wave幅值归一化
f.close()

'''
# wav文件写入
'''
# outData = waveData  # 待写入wav的数据，这里仍然取waveData数据
# outfile = filepath + 'out1.wav'
# outwave = wave.open(outfile, 'wb')  # 定义存储路径以及文件名
# nchannels = 1
# sampwidth = 2
# fs = 8000
# data_size = len(outData)
# framerate = int(fs)
# nframes = data_size
# comptype = "NONE"
# compname = "not compressed"
# outwave.setparams((nchannels, sampwidth, framerate, nframes,
#                    comptype, compname))
# #为什么要这么写入呢？应该不这么写也可以
# for v in outData:
#     outwave.writeframes(struct.pack('h', int(v * 64000 / 2)))  # outData:16位，-32767~32767，注意不要溢出
# outwave.close()

time = np.arange(0, nframes) * (1.0 / framerate)
# plot the wave
plt.plot(time, waveData)
plt.xlabel("Time(s)")
plt.ylabel("Amplitude")
plt.title("Single channel wavedata")
plt.grid('on')  # 标尺，on：有，off:无。
plt.show()
print("done1")
##另一种语音读取方式
f = open(filepath + filelist[1], 'rb')
bufferData = f.read()
waveData = np.frombuffer(bufferData, dtype=np.int16)

'''
#三通道音频读取
'''
# #
# import wave
# import matplotlib.pyplot as plt
# import numpy as np
# import os
#
# filepath = "./data/apple/"  # 添加路径
# filelist = os.listdir(filepath)  # 得到文件夹下的所有文件名称
# f = wave.open(filepath + filelist[0], 'rb')
# params = f.getparams()
# nchannels, sampwidth, framerate, nframes = params[:4]
# strData = f.readframes(nframes)  # 读取音频，字符串格式
# waveData = np.fromstring(strData, dtype=np.int16)  # 将字符串转化为int
# waveData = waveData * 1.0 / (max(abs(waveData)))  # wave幅值归一化
# waveData = np.reshape(waveData, [nframes, nchannels])
# f.close()
# # plot the wave
# time = np.arange(0, nframes) * (1.0 / framerate)
# plt.figure()
# plt.subplot(5, 1, 1)
# plt.plot(time, waveData[:, 0])
# print(waveData.shape)
# plt.xlabel("Time(s)")
# plt.ylabel("Amplitude")
# plt.title("Ch-1 wavedata")
# plt.grid('on')  # 标尺，on：有，off:无。
# plt.subplot(5, 1, 3)
# plt.plot(time, waveData[:, 1])
# plt.xlabel("Time(s)")
# plt.ylabel("Amplitude")
# plt.title("Ch-2 wavedata")
# plt.grid('on')  # 标尺，on：有，off:无。
# plt.subplot(5, 1, 5)
# plt.plot(time, waveData[:, 2])
# plt.xlabel("Time(s)")
# plt.ylabel("Amplitude")
# plt.title("Ch-3 wavedata")
# plt.grid('on')  # 标尺，on：有，off:无。
# plt.show()
# print("done2")

'''
#语谱图
'''
import wave
import matplotlib.pyplot as plt
import numpy as np
import os

filepath = "./data/apple/"  # 添加路径
filename = os.listdir(filepath)  # 得到文件夹下的所有文件名称
f = wave.open(filepath + filename[0], 'rb')
params = f.getparams()
nchannels, sampwidth, framerate, nframes = params[:4]
strData = f.readframes(nframes)  # 读取音频，字符串格式
waveData = np.fromstring(strData, dtype=np.int16)  # 将字符串转化为int
waveData = waveData * 1.0 / (max(abs(waveData)))  # wave幅值归一化
waveData = np.reshape(waveData, [nframes, nchannels]).T
f.close()
# plot the wave
plt.specgram(waveData[0], Fs=framerate, scale_by_freq=True, sides='default')
plt.ylabel('Frequency(Hz)')
plt.xlabel('Time(s)')
plt.show()
print("specgram done")

'''
#音频播放
'''
import wave
import pyaudio
import os

# wav文件读取
filepath = "./data/apple/"  # 添加路径
filename = os.listdir(filepath)  # 得到文件夹下的所有文件名称
f = wave.open(filepath + filename[0], 'rb')
params = f.getparams()
nchannels, sampwidth, framerate, nframes = params[:4]
# instantiate PyAudio
p = pyaudio.PyAudio()
# define stream chunk
chunk = 1024
# 打开声音输出流
stream = p.open(format=p.get_format_from_width(sampwidth),
                channels=nchannels,
                rate=framerate,
                output=True)

# 写声音输出流到声卡进行播放
data = f.readframes(chunk)
i = 1
while True:
    data = f.readframes(chunk)
    if data == b'': break
    stream.write(data)
f.close()
# stop stream
stream.stop_stream()
stream.close()
# close PyAudio
p.terminate()
print("pyaudio done")