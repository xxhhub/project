import scipy.signal as signal
import pylab as pl
import scipy.signal as signal
import wave
import matplotlib.pyplot as plt
import numpy as np
import os

#读取音频信号--集成为函数
def wavread(filename):
    f = wave.open(filename, 'rb')
    params = f.getparams()
    nchannels, sampwidth, framerate, nframes = params[:4]
    strData = f.readframes(nframes)  # 读取音频，字符串格式
    waveData = np.fromstring(strData, dtype=np.int16)  # 将字符串转化为int
    f.close()
    waveData = waveData * 1.0 / (max(abs(waveData)))  # wave幅值归一化
    waveData = np.reshape(waveData, [nframes, nchannels]).T
    return waveData

#分帧1
def enframe(signal, nw, inc):
    '''将音频信号转化为帧。
    参数含义：
    signal:原始音频型号
    nw:每一帧的长度(这里指采样点的长度，即采样频率乘以时间间隔)
    inc:相邻帧的间隔（同上定义）

    '''
    signal_length = len(signal)  # 信号总长度
    if signal_length <= nw:  # 若信号长度小于一个帧的长度，则帧数定义为1
        nf = 1
    else:  # 否则，计算帧的总长度
        nf = int(np.ceil((1.0 * signal_length - nw + inc) / inc))
    pad_length = int((nf - 1) * inc + nw)  # 所有帧加起来总的铺平后的长度
    zeros = np.zeros((pad_length - signal_length,))  # 不够的长度使用0填补，类似于FFT中的扩充数组操作
    pad_signal = np.concatenate((signal, zeros))  # 填补后的信号记为pad_signal
    indices = np.tile(np.arange(0, nw), (nf, 1)) + np.tile(np.arange(0, nf * inc, inc),
                                                           (nw, 1)).T  # 相当于对所有帧的时间点进行抽取，得到nf*nw长度的矩阵
    indices = np.array(indices, dtype=np.int32)  # 将indices转化为矩阵
    frames = pad_signal[indices]  # 得到帧信号
    #    win=np.tile(winfunc(nw),(nf,1))  #window窗函数，这里默认取1
    #    return frames*win   #返回帧信号矩阵
    return frames

#hamming窗
# pl.figure(figsize=(6,2))
# pl.plot(signal.hamming(512))
# pl.show()
#信号加窗分帧
def window_enframe(signal, nw, inc, winfunc):
    '''将音频信号转化为帧。
    参数含义：
    signal:原始音频型号
    nw:每一帧的长度(这里指采样点的长度，即采样频率乘以时间间隔) #frame_size更合适一些，帧的大小、窗口大小
    inc:相邻帧的间隔（同上定义）                          #hop_size 帧间距离，帧移
    https://www.bilibili.com/video/BV1P3411o7FD/?spm_id_from=333.337.search-card.all.click&vd_source=8bda6792e5451d902d93fdbb2b422f01
    调用方法：
    winfunc = signal.hamming(nw)
    Frame = window_enframe(data[0], nw, inc, winfunc)
    '''
    signal_length=len(signal) #信号总长度
    if signal_length<=nw: #若信号长度小于一个帧的长度，则帧数定义为1
        nf=1
    else: #否则，计算帧的总长度
        nf=int(np.ceil((1.0*signal_length-nw+inc)/inc))
    pad_length=int((nf-1)*inc+nw) #所有帧加起来总的铺平后的长度
    zeros=np.zeros((pad_length-signal_length,)) #不够的长度使用0填补，类似于FFT中的扩充数组操作
    pad_signal=np.concatenate((signal,zeros)) #填补后的信号记为pad_signal
    indices=np.tile(np.arange(0,nw),(nf,1))+np.tile(np.arange(0,nf*inc,inc),(nw,1)).T  #相当于对所有帧的时间点进行抽取，得到nf*nw长度的矩阵
    indices=np.array(indices,dtype=np.int32) #将indices转化为矩阵
    frames=pad_signal[indices] #得到帧信号
    win=np.tile(winfunc,(nf,1))  #window窗函数，这里默认取1
    return frames*win   #返回帧信号矩阵

def stft(signal, window, win_size, hop_size, last_sample=False):
    """Convert time-domain signal to time-frequency domain.
    (Short Time Fourier Transform, STFT)
    Args:
        signal   : multi-channel time-domain signal
        window   : window function, see cola_hamming as an example.
        win_size : window size (number of samples)
        hop_size : hop size (number of samples)
        last_sample : include last sample, by default (due to legacy bug),
                      the last sample is not included.
    Returns:
        tf       : multi-channel time-frequency domain signal.
    """
    assert signal.ndim == 2
    w = window(win_size, hop_size)
    return np.array([[
        np.fft.fft(c[t:t + win_size] * w)
        for t in range(0,
                       len(c) - win_size + (1 if last_sample else 0), hop_size)
    ] for c in signal])

def istft(tf, hop_size):
    """Inverse STFT
    Args:
        tf       : multi-channel time-frequency domain signal.
        hop_size : hop size (number of samples)
    Returns:
        signal   : multi-channel time-domain signal
    """
    tf = np.asarray(tf)
    nch, nframe, nfbin = tf.shape
    signal = np.zeros((nch, (nframe - 1) * hop_size + nfbin))
    for t in range(nframe):
        signal[:, t * hop_size:t * hop_size + nfbin] += \
            np.real(np.fft.ifft(tf[:, t]))
    return signal




# #短时傅里叶变换使用fft函数实现

# data:原始音频型号
# nw:每一帧的长度(这里指采样点的长度，即采样频率乘以时间间隔) #frame_size更合适一些，帧的大小、窗口大小
# inc:相邻帧的间隔（同上定义）                          #hop_size 帧间距离，帧移
# https://www.bilibili.com/video/BV1P3411o7FD/?spm_id_from=333.337.search-card.all.click&vd_source=8bda6792e5451d902d93fdbb2b422f01
# 调用方法：
N = 1024                        # 采样点数
sample_freq=120                 # 采样频率 120 Hz, 大于两倍的最高频率
framerate=sample_freq           #这些参数，搞明白
sample_interval=1/sample_freq   # 采样间隔
signal_len=N*sample_interval    # 信号长度
t=np.arange(0,signal_len,sample_interval)
data = 5 + 2 * np.sin(2 * np.pi * 20 * t) + 3 * np.sin(2 * np.pi * 30 * t) + 4 * np.sin(2 * np.pi * 40 * t)  # 采集的信号
frame_size=512
hop_size=128
winfunc = signal.hamming(frame_size)
Frame = window_enframe(data, frame_size, hop_size, winfunc)
n_fft=512
waveform_stft = np.fft.rfft(Frame,n_fft)
# waveform_stft = stft(wavedata[0],signal.hamming,n_fft,inc)

#功率谱
waveform_pow =  np.abs(waveform_stft)**2/n_fft
waveform_db = 20*np.log10(waveform_pow)

plt.figure(figsize=(6,6))
plt.imshow(waveform_db)
y_ticks=np.arange(0,int(n_fft/2),100)
plt.yticks(ticks=y_ticks,labels=y_ticks*framerate/n_fft)


plt.figure()
plt.specgram(data, Fs=framerate, scale_by_freq=True, sides='default')
plt.ylabel('Frequency(Hz)')
plt.xlabel('Time(s)')
plt.show()
print("specgram done")



# #短时傅里叶变换使用plt.specgram函数实现
# # Implementation of matplotlib function
# import matplotlib.pyplot as plt
# import numpy as np
#
# np.random.seed(9360801)
#
# dt = 0.001
# t = np.arange(0.0, 20.0, dt)
# s1 = np.sin(4 * np.pi * 100 * t)
# s2 = 1.5 * np.sin(1.5 * np.pi * 400 * t)
#
# s2[t <= 10] = s2[12 <= t] = 0
#
# nse = 0.2 * np.random.random(size=len(t))
#
# x = s1 + s2 + nse
# NFFT = 512
# Fs = int(1.0 / dt)
#
# plt.figure()
# plt.plot(x)#离散信号采用plot、stem都行
# plt.figure()
# plt.specgram(x,Fs=Fs,cmap='viridis')
# plt.title('matplotlib.pyplot.specgram() Example\n',
#           fontsize=14, fontweight='bold')
#
# #短时傅里叶变换使用signal.stft函数实现
# fs = 1024  # 采样频率
# f, t, nd = signal.stft(x, fs=fs, window='hann', nperseg=256, noverlap=None, nfft=None,
#                        detrend=False, return_onesided=True, boundary='zeros', padded=True, axis=-1)
# #  fs:时间序列的采样频率,  nperseg:每个段的长度，默认为256(2^n)   noverlap:段之间重叠的点数。如果没有则noverlap=nperseg/2
#
# # window ： 字符串或元祖或数组，可选需要使用的窗。
# # #如果window是一个字符串或元组，则传递给它window是数组类型，直接以其为窗，其长度必须是nperseg。
# # 常用的窗函数有boxcar，triang，hamming， hann等，默认为Hann窗。
#
# # nfft ： int，可选。如果需要零填充FFT，则为使用FFT的长度。如果为 None，则FFT长度为nperseg。默认为无
#
# # detrend ： str或function或False，可选
# # 指定如何去除每个段的趋势。如果类型参数传递给False，则不进行去除趋势。默认为False。
#
# # return_onesided ： bool，可选
# # 如果为True，则返回实际数据的单侧频谱。如果 False返回双侧频谱。默认为 True。请注意，对于复杂数据，始终返回双侧频谱。
#
# # boundary ： str或None，可选
# # 指定输入信号是否在两端扩展，以及如何生成新值，以使第一个窗口段在第一个输入点上居中。
# # 这具有当所采用的窗函数从零开始时能够重建第一输入点的益处。
# # 有效选项是['even', 'odd', 'constant', 'zeros', None].
# # 默认为‘zeros’,对于补零操作[1, 2, 3, 4]变成[0, 1, 2, 3, 4, 0] 当nperseg=3.
#
# # 填充： bool，可选
# # 指定输入信号在末尾是否填充零以使信号精确地拟合为整数个窗口段，以便所有信号都包含在输出中。默认为True。
# # 填充发生在边界扩展之后，如果边界不是None，则填充为True，默认情况下也是如此。
#
# # axis ： int，可选
# # 计算STFT的轴; 默认值超过最后一个轴(即axis=-1)。
#
# plt.figure()
# plt.pcolormesh(t, f, np.abs(nd),cmap='viridis',vmin=-2, vmax=2)#vmin=np.min(np.abs(nd)), vmax=np.max(np.abs(nd))
# plt.title('STFT')
# plt.ylabel('frequency')
# plt.xlabel('time')
#
#
# plt.show()
# print("done")