%https://blog.csdn.net/CCunun/article/details/117756849

% %1.语音信号采集
% fs = 8000;          % 采样频率
% duration = 2;        % 时间长度(秒） 
% n = duration*fs;     % 采样点数
% t = (1:n)/fs;
% %创建一个录音文件：fs =8000
% recObject = audiorecorder(fs, 16, 1);   
% fprintf('开始录音:\n');pause(0);
% recordblocking(recObject, duration);
% stop(recObject);
% fprintf('录制结束\n');
% play(recObject);        % 播放录制的音频
% y = getaudiodata(recObject);
% ymax = max(abs(y));      % 归一化
% y = y/ymax;
%  
% %2.绘制波形图，见图1
% audiowrite('audio1.wav', y, fs);      % 写入音频 
% figure(1);
% plot(t, y);
% xlabel('时间/s');
% ylabel('幅度');
% title('(a)fs = 8000');

Fs = 1000;             %采样率
fs=Fs;
T = 1/Fs;              %采样时间单位
L = 1000;              %信号长度
t = (0:L-1)*T;         %时间序列

x = 0.7*sin(2*pi*50*t) + sin(2*pi*120*t);  %原始信号
y = x;% + 2*randn(size(t));                  %原始信号叠加了噪声后
figure(1);
plot(Fs*t(1:50),y(1:50));                  %绘制波形
title('原始信号+零均值随机噪声 ');
xlabel('时间单位:ms');

%对语音信号8000点进行FFT变换
d=fft(y,8000);	%对语音信号8000点进行FFT变换
figure(2);
subplot(2,2,1);
plot(abs(d));
xlabel('频率');
ylabel('幅度');
title('8000点幅度谱');
grid;
subplot(2,2,2);
plot(angle(d));
xlabel('频率');
ylabel('angle(d)');
title('8000点相位谱');
grid;

%对16000个数据进行分析,如图4所示。
d=fft(y,16000);	%对语音信号进行FFT变换
d1=fftshift(d);
figure(3);
subplot(2,2,1);
plot(abs(d1));
xlabel('频率');
ylabel('幅度');
title('16000幅度谱');
grid;
subplot(2,2,2);
plot(angle(d1));
xlabel('频率');
ylabel('angle(d)');
title('16000相位谱');
grid;

% 针对电话信道（最高3500Hz），设计一个FIR或IIR滤波器进行滤波，把抽样率转变为7000Hz/s，并进行频谱分析，得到幅度和相位谱。
% 设计一个针对电话信道的IIR型低通滤波器，如图5所示。

%利用buttord设计IIR低通滤波器
rp=0.5;rs=60;   %通带波纹系数rp，最小阻带衰减rs
Ft=7000;
Fp=1200;
Fs=2000;                                       
wp=2*pi*Fp/Ft;
ws=2*pi*Fs/Ft;            %求出待设计的模拟滤波器的边界频率
[n,wn]=buttord(wp,ws,rp,rs,'s') %低通滤波器的阶数和截止频率
[b,a]=butter(n,wn,'s');         %滤波器的传输函数
[bz,az]=bilinear(b,a,0.5); 
%利用双线性变换实现频率响应S域到Z域的变换
%低通滤波器特性
figure(4);
[h,w]=freqz(bz,az);		%利用freqz函数求频率响应
subplot(2,1,1);
plot(w*fs/(2*pi),abs(h));	%二维连续图形

title('IIR低通滤波器');
xlabel('\omega/\pi');
ylabel('振幅');
subplot(2,1,2);
plot(w/pi,20*log10(abs(h)));

title('IIR低通滤波器');
xlabel('\omega/\pi');
ylabel('振幅');

%利用ellipord设计IIR低通滤波器，如图6所示。
figure(5);
subplot(1,1,1);
Fp=1200;
Fs=2000;
Ft=7000;
As=60;
Ap=0.5;
wp=2*pi*Fp/Ft;
ws=2*pi*Fs/Ft;
[n,wn]=ellipord(wp,ws,Ap,As,'s');
[b,a]=ellip(n,Ap,As,wn,'s');
[B,A]=bilinear(b,a,1);
[h,w]=freqz(B,A);		%利用freqz函数求频率响应
plot(w*Ft/pi/2,abs(h));
title('IIR低通滤波器');
xlabel('频率');
ylabel('幅度');


%5.对录制的声音进行滤波处理，如图7所示。
fs=8000;

figure(6);
f=filter(bz,az,y);    %滤波
f1=fft(f,1024);
subplot(2,1,1)
plot(abs(f1));  %滤波后的时域图
title('滤波后的幅度谱');
grid;
subplot(2,1,2)
plot(angle(f1));    %滤波后的时域图
title('滤波后的相位谱');
grid;
audiowrite('audio2.wav',f,fs);
%对滤波后的声音进行储存。

% % 6.将处理后的声音与原声音进行对比，如图8所示。
% fs=8000;
% y=audioread('audio1.wav');
% y1=audioread('audio2.wav');
% yx=fft(y);
% yx1=fft(y1);
% figure(7);
% subplot(2,1,1)
% plot(20*log10(abs(yx)));
% title('滤波前的相对幅度谱');
% subplot(2,1,2);
% plot(20*log10(abs(yx1)));
% title('滤波后的相对幅度谱');
% 
% % 7.回放语音信号
% clear
% clc
% [audio1,fs]=audioread('audio1.wav');
% sound(audio1,fs);
% pause(2);
% [audio2,fs]=audioread('audio2.wav');
% sound(audio2,fs);