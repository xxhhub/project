%%https://zhuanlan.zhihu.com/p/143510464

% s = spectrogram(x, window, noverlap, nfft, fs)
% [s, f, t] = spectrogram(x, window, noverlap, nfft, fs)
% [s, f, t, p] = spectrogram(x, window, noverlap, f, fs)
% x表示输入信号；
% window表示窗函数，如果window的值是一个整数，那么被分段的x的每一段的长度都等于window，并采用默认的Hamming窗；如果window是一个向量，那么被分段后每一段的长度都等于length(window)，且输入的向量即为所要加的窗函数；
% overlap表示两段之间的重合点数，overlap的值必须要小于窗长，如果没有指定overlap，默认是窗长的一半，即50%的overlap；
% nfft表示fft的点数，fft的点数跟窗长可以是不同的，当没有指定该参数时，Matlab会取max(256, 2^(ceil(log2(length(window)))))，即当窗长小于256时，fft的点数是256；当窗长大于256时，fft的点数取大于窗长的最小的2的整数次幂；
% fs表示采样率，用来归一化显示使用；
% f表示显示的频谱范围，f是一个向量，长度跟s的行数相同；
% 当x是实信号且nfft为偶数时，s的行数为(nfft/2+1)
% 当x是实信号且nfft为奇数时，s的行数为(nfft+1)/2
% 当x是复信号时，s的行数为nfft
% 当在输入的参数列表中指定f后，函数会在f指定的频率处计算频谱图，返回的f跟输入的f是相同的；
% t表示显示的时间范围，是一个向量，长度跟s的列数相同；
% p表示功率谱密度，对于实信号，p是各段PSD的单边周期估计；对于复信号，当指定F频率向量时，P为双边PSD;如何计算PSD

clc;clear all;close all;
fs = 10e6;
n = 10000;
f1 = 10e3; f2 = 50e3; f3 = 80e3; f4 = 100e3;
t = (0:n-1)'/fs;
sig1 = cos(2*pi*f1*t);
sig2 = cos(2*pi*f2*t);
sig3 = cos(2*pi*f3*t);
sig4 = cos(2*pi*f4*t);

sig = [sig1; sig2; sig3; sig4];

s = spectrogram(sig, 256);
t = linspace(0, 4*n/fs, size(s,1));
f = linspace(0, fs/2, size(s,2));
figure;
imagesc(t, f, 20*log10((abs(s))));xlabel('Samples'); ylabel('Freqency');
colorbar;

s = spectrogram(sig, 256, 255);
t = linspace(0, 4*n/fs, size(s,1));
f = linspace(0, fs/2, size(s,2));
figure;
imagesc(t, f, 20*log10((abs(s))));xlabel('Samples'); ylabel('Freqency');
colorbar;

window = 2048;
noverlap = window/2;
nfft = 256;
f_len = window/2 + 1;
f = linspace(0, 150e3, f_len);
[s, f, t] = spectrogram(sig, window, noverlap , f, fs);
figure;
imagesc(t, f, 20*log10((abs(s))));xlabel('Samples'); ylabel('Freqency');
colorbar;

[s, f, t, p] = spectrogram(sig, window, nfft, f, fs);
figure;
imagesc(t, f, p);xlabel('Samples'); ylabel('Freqency');
colorbar;

%stft函数
window = 2048;
noverlap = window/2;
nfft = window;
[s, f, t, p] = spectrogram(sig, window, noverlap, nfft, fs);
figure;
imagesc(t, f, 20*log10((abs(s))));xlabel('Samples'); ylabel('Freqency');
title('使用spectrogram画出的短时傅里叶变换图形');
colorbar;

ss = stft(sig,fs,'Window',hamming(window),'OverlapLength',window/2,'FFTLength',nfft);
figure;
imagesc(t, f, 20*log10((abs(ss(1024:end,:)))));xlabel('Samples'); ylabel('Freqency');
title('使用stft画出的短时傅里叶变换图形');
colorbar;