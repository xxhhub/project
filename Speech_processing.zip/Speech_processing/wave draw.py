#.wav文件读取，wav文件如何编码，如何读取。和.jpg不太一样
#wave data get  -xlxw

#import
import wave as we
import numpy as np
import matplotlib.pyplot as plt

def wavread(path):
    wavfile =  we.open(path,"rb")
    params = wavfile.getparams()
    framesra,frameswav= params[2],params[3]
    datawav = wavfile.readframes(frameswav)
    wavfile.close()
    datause = np.fromstring(datawav,dtype = np.short)
    datause.shape = -1,2
    datause = datause.T
    time = np.arange(0, frameswav) * (1.0/framesra)
    return datause,time

def main():


    file = open("./data/piano_music/piano_c.wav", "rb")
    # 读取wav前四个字节内容  -xlxw
    s = file.read(4)
    print(s)

    # 读取wav前44个字节内容  -xlxw
    s1 = file.read(44)
    print(s1)


    path =  "./data/piano_music/piano_c.wav"#input("The Path is:")
    wavdata,wavtime = wavread(path)
    plt.title("Night.wav's Frames")
    plt.subplot(211)
    plt.plot(wavtime, wavdata[0],color = 'green')
    plt.subplot(212)
    plt.plot(wavtime, wavdata[1])
    plt.show()
    
main()

